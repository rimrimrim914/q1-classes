print('Calculate Radius of your circle')

#Getting Input from User 
radius_of_circle = float(input('Enter the Radius of your circle '))

#Now we Calculate the Area of the Circle
Area = 3.14 * (radius_of_circle*radius_of_circle)

#Output of the program
print(f'Area {Area} with radius of Circle {radius_of_circle}')